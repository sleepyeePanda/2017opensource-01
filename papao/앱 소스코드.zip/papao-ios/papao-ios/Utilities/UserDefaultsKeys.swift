//
//  UserDefaultsKeys.swift
//  papao-ios
//
//  Created by closer27 on 2017. 11. 17..
//  Copyright © 2017년 papaolabs. All rights reserved.
//

import Foundation

enum UserDefaultsKeys: String {
    case deviceToken
    case loggedUser
}
