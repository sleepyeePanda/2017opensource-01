package com.papaolabs.batch.infrastructure.feign.openapi.dto;

import lombok.Data;

@Data
public class PushDTO {

}
