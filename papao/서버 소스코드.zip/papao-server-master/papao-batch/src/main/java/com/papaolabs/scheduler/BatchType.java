package com.papaolabs.scheduler;

public enum BatchType {
    YEAR, MONTH, DAY
}