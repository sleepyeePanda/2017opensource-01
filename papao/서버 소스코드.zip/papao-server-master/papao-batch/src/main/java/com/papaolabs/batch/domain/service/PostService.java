package com.papaolabs.batch.domain.service;

public interface PostService {
    void syncPostList(String beginDate, String endDate);
}