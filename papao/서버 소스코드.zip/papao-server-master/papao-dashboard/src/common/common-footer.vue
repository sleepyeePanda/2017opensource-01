<template>
  <footer class="mdl-mega-footer">
    <div class="mdl-mega-footer--bottom-section">
      <ul class="mdl-mega-footer--link-list">
        <li><a href="https://github.com/papaolabs/">Github</a></li>
      </ul>
    </div>
  </footer>
</template>

<script>
  export default {
    name: 'footer',
  };
</script>

<style scoped>

</style>
