package com.papaolabs.push.domain.model;

public class PushResult {
}
