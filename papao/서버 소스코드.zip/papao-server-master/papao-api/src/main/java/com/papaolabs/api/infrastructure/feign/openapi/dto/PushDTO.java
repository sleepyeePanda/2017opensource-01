package com.papaolabs.api.infrastructure.feign.openapi.dto;

import lombok.Data;

@Data
public class PushDTO {

}
