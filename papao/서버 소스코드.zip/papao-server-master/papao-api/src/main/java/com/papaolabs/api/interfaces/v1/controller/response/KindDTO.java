package com.papaolabs.api.interfaces.v1.controller.response;

import lombok.Data;

@Data
public class KindDTO {
    private Long upKindCode;
    private Long kindCode;
    private String kindName;
}
