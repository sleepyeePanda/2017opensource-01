from django.apps import AppConfig


class VisionControllerConfig(AppConfig):
    name = 'vision_controller'
