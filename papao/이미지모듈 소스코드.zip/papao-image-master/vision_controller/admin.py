from django.contrib import admin
from .models import VisionTb
# Register your models here.

admin.site.register(VisionTb)