from django.apps import AppConfig


class BatchControllerConfig(AppConfig):
    name = 'batch_controller'
