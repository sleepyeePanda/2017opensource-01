from django.apps import AppConfig


class AwsControllerConfig(AppConfig):
    name = 'aws_controller'
